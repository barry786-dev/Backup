import React from 'react';
import './DataList.css';
const DataList = (props) => {// here is the dataList componenet , it has props which i pass them from his father App.js and inside this props there is my data which i want to put it inside my list.

  // so io will return <ul> inside my ul must be many <li> each <li> muat has one element from my array data as we aid our data is array of objects , that mean each element in this arra yis object but now we do not care if its object or whatever we call each item in our array element , so inside my <ul>, I need to creat many <li> one li for each element in my array,so to loop inside my array and return new array each element of my new array must be <li> the context of this li must be the element of my old array , so i will use map method on my old array like you can see below inside my ul..i will use my data which inside my props and my data itself is array as we said...so props.data.map(()=>) you know map will return new array with new value which we decide , so we will return each time <li>inside it first item in my old array<li> ...
  //of course i used JSON.stringify(item)..becuase my item(each of my daa array element) is js an object , and i can only put text as <li> context , so i need to change it to string using JSON.stringify(item).
  // that is it after map loop inside my array it will give back new array each elemnt of this array is <li> insid eit first object ..and so on...i just wrap these array which map give it back between two curly braces{ } so the value of this new rray which is many <li>s will extract between the <ul>..now i have ul list with all the data....of course this ul will return back by my DataList component which is appear in my App.js and it will appear at the screen 
  return (
    <ul className='ul'> 
      {props.data.map((item) => {
        return (
          <li>
            {JSON.stringify(item)}
          </li>
        );
      })}
    </ul>
  );
};
export default DataList;
//important note  : react need index to deal with the list in right way, but nw i did not use it to do not confuse it , but this code in this form is nt perfect , but is enough to answer the question .
// if you have any quetsion please ask me
            