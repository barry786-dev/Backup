// these green comments only for explination , you can just delete all of them after you read them, and see how much the code is short, if you have any question please ask me.
import { React, useState } from 'react';
import './App.css';
import DataList from './components/DataList';

function App() {
  const [fetchedData, setFetchedData] = useState(''); // here we just add useState the init value is empty , later by press the button and fire the onClickHandler function will fetch the data from the address and we will assign it to fetchedData variable using of course setFetchedData , becuase react working like this , you can not ssain value to state dierectly you need to use the function inside the array above in usestate hook. 
  const onClickHandler = () => { // this onClickHandler will be fired by click in the button, it will fetch the data from the addressbfirst then we need to change this data from string to be normal js data by using json()
    fetch('https://jsonplaceholder.typicode.com/users')
      .then((response) => response.json())
      .then((json) => setFetchedData(json));//you can write this line insted if you like to see the data how it look like .then((json) => conole.log(json)); but of course i do not want to log the data to the console, i want to assign it to my state variable which is fetcheddata by passing these data to setFetchedData function like you can see clearly in the last line of the function onClickHandler.
      // so it is easy three steps , first fetch the data then convert it from string to js data by using json then assign it to my state using state set function...
      // just to know the last data after conver it if you console.log it you will see that it is array of objects and these objects has other nested objects, but now we do not care , we only need to put it on the screen without styling so the data is like this [{},{},{}....etc].
      // i will put it at the screen by using compenent i called it DataList..you can go to DataList.js file to see what is insid ethis component , it is only a <ul> inside it <li>,let us read the last line in this code first
  };
  return ( // ok bro here what we return only button when you click on it will fire the function onClickhandler, please check the function above to see what is hppen before you chek the other element below the button .
    <div className='App'>
      <button className='button' onClick={onClickHandler}>Fetch Data</button>
      {fetchedData ? <DataList data={fetchedData}></DataList> : ''}
    </div>
  ); // the lst line under the button is jsx is saying check the state variable if there is data inside it that mean true then ? show the Datalist component otherwise : '' show nothing, that mean only after click the button and the function onClickHndler get fiered and the data become inside our state fetchedData , only in this case DataList will appear on the screen...let us now go to read the DataList file component as i said befor eit is just a ul list, i passed my state variable fetchedData to it as props becuase my data which i want to show it inside my ul list is insise fetchedData .  
}

export default App;
